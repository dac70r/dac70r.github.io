//ONLY SUBMIT THIS FILE TO ZINC
#include "given.h"
#include "todo.h"
#include <iostream>
using namespace std;
//be reminded that you should NOT include any additional library, please read "Additional Notes" on the PA3 webpage 

Node*** generateMap(int width, int height)
{
    return nullptr; //it is a dummy return statement, you can remove it if you want
}

void printHeroStatus(const HeroStatus& heroStatus)
{

}

void printMonsterCount(Node*** map, int width, int height)
{

}

int getLinkedListLength(const Node* head)
{
    return 0;
}

bool addThing(Node*** map, int width, int height, int x, int y, Thing thing, int quantity)
{
    return true;
}

bool removeThing(Node*** map, int width, int height, int x, int y, Thing thing, int quantity)
{
    return true;
}

void deleteLinkedList(Node*& head)
{
    
}

void deleteMap(Node*** map, int width, int height)
{
    
}

bool moveHero(char move, Node*** map, int width, int height, HeroStatus &heroStatus)
{
    return true;
}

int getMonsterCount(Node*** map, int width, int height)
{
    return 99;
}

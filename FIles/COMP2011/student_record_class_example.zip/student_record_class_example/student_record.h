#include <iostream>
#include <cstring>
using namespace std;

const int MAX_NAME_LEN = 20;

// class definition
class student_record{
private:     
   // data members
   char gender;
   //char name[MAX_NAME_LEN]; // static array
   char* name; // dynamic array
   unsigned int id;

   // member function
   // private function can only be used in other
   // member functions
   //void fun() { cout << "fun():" << name << endl; } // no const -> mutator

public: 
   // member functions
   // default constructor: no arguments
   // typically, do initialization
   student_record();
   // another constructor, with arguements
   student_record(char, const char[], unsigned int);
   // destructor
   ~student_record();
   // accessor --> read data members only (not modifying)
   unsigned int get_id() const;
   void print() const;
   // mutator: (no const) modifying the data members   void set(char, const char [], int);
   void set(char, const char [], int);
};

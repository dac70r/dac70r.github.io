#include "student_record.h"

// member function definitionis

// default constructor: no arguments
// typically, do initialization
student_record::student_record() { cout << "student_record()" << endl;
    //gender = '\0'; strcpy(name, ""); id = 0; // not valid if name is not static array
    gender = '\0'; name = nullptr; id = 0;
}

// another constructor, with arguements
student_record::student_record(char g, const char n[], unsigned int i) {
    cout << "student_record(char, const char[], unsigned int)" << endl;
    name = new char[strlen(n) + 1];
    gender = g; strcpy(name, n); id = i;
    // alternatively:
    // name = nullptr; set(g, n, i); 
}

// destructor
student_record::~student_record() { // default destructor // no arguments
    cout << "~student_record():" << name << endl;
    if (name != nullptr) delete [] name; 
} 

// accessor --> read data members only (not modifying)
unsigned int student_record::get_id() const { 
    // id = 0; // invalid: get_id() is an accessor
    return id; 
}

void student_record::print() const {
    // fun();  // invalid: fun() is mutator and print() is accessor
                 // cannot call a mutator member function inside an accessor
    cout << name << endl << id << endl << gender << endl;
    // name is the data member of a student_record object
}

// mutator: (no const) modifying the data members
void student_record::set(char g, const char n[], int i) {
    // fun(); // ok to call a private member function inside
              // another member function
    // allocate/reallocate memory
    if (name != nullptr)
        delete [] name;
    name = new char[strlen(n) + 1]; 

    gender = g; id = i; strcpy(name, n);
}

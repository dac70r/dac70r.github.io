#include "student_record.h"

int main() {
    student_record newstudent; // static object --> default constructor
    newstudent.set('F', "Amy", 12345678);
    // cout << newstudent.name << endl; // invalid: name is private
    cout << "In main: " << newstudent.get_id() << endl;
    // newstudent.id = 0; // invalid: id is private
    // newstudent.fun(); // invalid: fun() is private
    newstudent.print();

    student_record anotherstudent('M', "John", 12456789); 
                   // static object, another constructor
    anotherstudent.print();
    //newstudent = anotherstudent; // assignment, but needs to be careful

    student_record* p1 = new student_record; // dynamic object, default constructor
    p1->set('F', "Helen", 21234567);
    p1->print();
    delete p1; // avoid memory leak 
    p1 = nullptr; // better reset if variable p1 is used later,
                  // otherwise, not necessary 

    student_record* p2 = new student_record('M', "Ben", 31234567);
                         // dynamic object, another constructor
    p2->print();
    delete p2;
    return 0;
} // end of score for newstudent, anotherstudent